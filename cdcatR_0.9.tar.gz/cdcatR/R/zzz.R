.onLoad <- function(...) {
  packageStartupMessage("cdcatR Package [Version 0.9; 2019-2-28]
                        More information: https://github.com/miguel-sorrel/cdcatR")
}
