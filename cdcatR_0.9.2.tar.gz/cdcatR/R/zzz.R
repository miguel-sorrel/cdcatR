.onLoad <- function(...) {
  packageStartupMessage("cdcatR Package [Version 0.9.2; 2019-10-16]
                        More information: https://github.com/miguel-sorrel/cdcatR")
}
